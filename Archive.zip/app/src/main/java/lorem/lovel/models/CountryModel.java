package lorem.lovel.models;

/**
 * Created by mrgn on 13/12/2016.
 *
 */

public class CountryModel {
    public String name;

    public CountryModel(String pName) {
        name = pName;
    }
}
